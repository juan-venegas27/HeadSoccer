package domain;

/**
 * Automated test suite for Head Soccer domain logic and physics.
 * Tests player movement, boundaries, jump physics, ball collisions,
 * bounce mechanics, goal detection, scoreboard updates, and timer expiration.
 */
public class HeadSoccerTest {

    private static int testsPassed = 0;
    private static int testsTotal  = 0;

    public static void main(String[] args) {
        System.out.println("============================================");
        System.out.println("  RUNNING HEAD SOCCER AUTOMATED TEST SUITE  ");
        System.out.println("============================================\n");

        runTest("Player Movement and Boundaries", HeadSoccerTest::testPlayerMovementAndBounds);
        runTest("Player Jump and Gravity", HeadSoccerTest::testPlayerJumpAndGravity);
        runTest("Player-Player Collision", HeadSoccerTest::testPlayerPlayerCollision);
        runTest("Ball Gravity and Ground Bounce", HeadSoccerTest::testBallGravityAndBounce);
        runTest("Ball Ceiling and Crossbar Bounce", HeadSoccerTest::testBallCeilingAndCrossbar);
        runTest("Player-Ball Head Collision Separation", HeadSoccerTest::testPlayerBallCollisionHead);
        runTest("Player-Ball Foot Collision Separation", HeadSoccerTest::testPlayerBallCollisionFoot);
        runTest("Player Hit / Kick", HeadSoccerTest::testPlayerHit);
        runTest("Left Goal Detection (Player 2 Scores)", HeadSoccerTest::testLeftGoalDetection);
        runTest("Right Goal Detection (Player 1 Scores)", HeadSoccerTest::testRightGoalDetection);
        runTest("Goal Freeze and Reset (No Double Counting)", HeadSoccerTest::testGoalFreezeAndReset);
        runTest("Clock Countdown, Pause, and Match End", HeadSoccerTest::testClockAndMatchEnd);

        System.out.println("\n============================================");
        System.out.printf("  RESULTS: %d / %d tests passed successfully%n", testsPassed, testsTotal);
        System.out.println("============================================");

        if (testsPassed != testsTotal) {
            System.exit(1);
        }
    }

    private static void runTest(String name, Runnable test) {
        testsTotal++;
        try {
            test.run();
            testsPassed++;
            System.out.println("[PASS] " + name);
        } catch (Throwable t) {
            System.err.println("[FAIL] " + name + ": " + t.getMessage());
            t.printStackTrace();
        }
    }

    private static void assertTrue(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static void assertEquals(double expected, double actual, double delta, String message) {
        if (Math.abs(expected - actual) > delta) {
            throw new AssertionError(message + " (expected " + expected + ", got " + actual + ")");
        }
    }

    private static void testPlayerMovementAndBounds() {
        HeadSoccer game = new HeadSoccer(900, 540);
        Player p1 = game.getPlayer1();
        int leftGoalLine = game.getField().getLeftGoalLine();

        p1.setMovingLeft(true);
        for (int i = 0; i < 200; i++) {
            p1.update(leftGoalLine + Player.HEAD_RADIUS, 900, game.getField().getGroundY());
        }
        p1.setMovingLeft(false);

        assertTrue(p1.getPositionX() >= leftGoalLine + Player.HEAD_RADIUS,
                "Player 1 must not cross past the left goal line: pos=" + p1.getPositionX());
    }

    private static void testPlayerJumpAndGravity() {
        HeadSoccer game = new HeadSoccer(900, 540);
        Player p1 = game.getPlayer1();
        int groundY = game.getField().getGroundY();
        double initialY = groundY - Player.HEAD_RADIUS;

        assertTrue(p1.isOnGround(), "Player should start on ground");

        p1.jump();
        p1.update(0, 900, groundY);

        assertTrue(!p1.isOnGround(), "Player should be airborne after jump");
        assertTrue(p1.getPositionY() < initialY, "Player Y should decrease during jump ascent");

        for (int i = 0; i < 80; i++) {
            p1.update(0, 900, groundY);
        }

        assertTrue(p1.isOnGround(), "Player should land back on ground after jump");
        assertEquals(initialY, p1.getPositionY(), 0.1, "Player Y should be on the floor after landing");
    }

    private static void testPlayerPlayerCollision() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();
        Player p1 = game.getPlayer1();
        Player p2 = game.getPlayer2();

        p1.setMovingRight(true);
        p2.setMovingLeft(true);

        for (int i = 0; i < 200; i++) {
            game.update();
        }

        assertTrue(p1.getPositionX() < p2.getPositionX(),
                "Player 1 must remain on left of Player 2: p1=" + p1.getPositionX() + " p2=" + p2.getPositionX());
        double dist = p2.getPositionX() - p1.getPositionX();
        assertTrue(dist >= Player.HEAD_RADIUS * 2 - 0.5,
                "Players must not overlap horizontally: dist=" + dist);
    }

    private static void testBallGravityAndBounce() {
        HeadSoccer game = new HeadSoccer(900, 540);
        Ball ball = game.getBall();
        int groundY = game.getField().getGroundY();

        ball.setPosition(450, 200);
        ball.setVelocity(0, 0);

        game.start();
        for (int i = 0; i < 30; i++) {
            ball.move(game.getField());
        }

        assertTrue(ball.getPositionY() > 200, "Ball should fall due to gravity");

        for (int i = 0; i < 60; i++) {
            ball.move(game.getField());
        }

        assertTrue(ball.getPositionY() <= groundY - Ball.RADIUS + 0.1,
                "Ball must not penetrate the ground: Y=" + ball.getPositionY());
    }

    private static void testBallCeilingAndCrossbar() {
        HeadSoccer game = new HeadSoccer(900, 540);
        Ball ball = game.getBall();

        ball.setPosition(450, 25);
        ball.setVelocity(0, -10);

        ball.move(game.getField());
        ball.move(game.getField());

        assertTrue(ball.getPositionY() >= Ball.RADIUS,
                "Ball must bounce off ceiling and not exceed it: Y=" + ball.getPositionY());
        assertTrue(ball.getVelocityY() > 0,
                "Ball vertical velocity should reflect downwards after ceiling hit: vy=" + ball.getVelocityY());

        int leftGoalLine = game.getField().getLeftGoalLine();
        int goalTop = game.getField().getGoalTop();
        ball.setPosition(leftGoalLine / 2.0, goalTop - 30);
        ball.setVelocity(0, 8);

        for (int i = 0; i < 10; i++) {
            ball.move(game.getField());
        }

        assertTrue(ball.getPositionY() <= goalTop - Ball.RADIUS + 1.0,
                "Ball must bounce on top of crossbar and not sink into goal from above: Y=" + ball.getPositionY());
    }

    private static void testPlayerBallCollisionHead() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();
        Player p1 = game.getPlayer1();
        Ball ball = game.getBall();

        ball.setPosition(p1.getPositionX(), p1.getPositionY() - 45);
        ball.setVelocity(0, 6);

        game.update();

        double dx = ball.getPositionX() - p1.getPositionX();
        double dy = ball.getPositionY() - p1.getPositionY();
        double dist = Math.sqrt(dx * dx + dy * dy);
        double minDist = Player.HEAD_RADIUS + Ball.RADIUS;

        assertTrue(dist >= minDist - 0.5,
                "Ball must be pushed outside player head: dist=" + dist + ", minDist=" + minDist);
        assertTrue(ball.getVelocityY() < 0,
                "Ball must receive an upward bounce impulse: vy=" + ball.getVelocityY());
    }

    private static void testPlayerBallCollisionFoot() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();
        Player p1 = game.getPlayer1();
        Ball ball = game.getBall();

        double footX = p1.getFootX();
        double footY = p1.getFootY();

        ball.setPosition(footX - 25, footY);
        ball.setVelocity(5, 0);

        game.update();

        double dx = ball.getPositionX() - footX;
        double dy = ball.getPositionY() - footY;
        double dist = Math.sqrt(dx * dx + dy * dy);
        double minDist = Player.FOOT_RADIUS + Ball.RADIUS;

        assertTrue(dist >= minDist - 0.5,
                "Ball must be pushed outside player foot: dist=" + dist + ", minDist=" + minDist);
    }

    private static void testPlayerHit() {
        HeadSoccer game = new HeadSoccer(900, 540);
        Player p1 = game.getPlayer1();
        Ball ball = game.getBall();

        ball.setPosition(p1.getPositionX() + 35, p1.getPositionY());
        ball.setVelocity(0, 0);

        p1.hit(ball);

        assertTrue(ball.getVelocityX() > 5.0,
                "Hit should give positive forward velocity: vx=" + ball.getVelocityX());
        assertTrue(ball.getVelocityY() < 0,
                "Hit should give upward velocity: vy=" + ball.getVelocityY());
    }

    private static void testLeftGoalDetection() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();
        Ball ball = game.getBall();
        int leftGoalLine = game.getField().getLeftGoalLine();
        int goalTop = game.getField().getGoalTop();

        ball.setPosition(leftGoalLine - 2, goalTop + 40);
        ball.setVelocity(-10, 0);

        for (int i = 0; i < 5; i++) {
            game.update();
        }

        assertEquals(0, game.getScoreboard().getScorePlayer1(), 0, "Player 1 should have 0 goals");
        assertEquals(1, game.getScoreboard().getScorePlayer2(), 0, "Player 2 should have scored 1 goal");
        assertTrue(game.isGoalFreeze(), "Game should be in goal freeze celebration");
    }

    private static void testRightGoalDetection() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();
        Ball ball = game.getBall();
        int rightGoalLine = game.getField().getRightGoalLine();
        int goalTop = game.getField().getGoalTop();

        ball.setPosition(rightGoalLine + 2, goalTop + 40);
        ball.setVelocity(10, 0);

        for (int i = 0; i < 5; i++) {
            game.update();
        }

        assertEquals(1, game.getScoreboard().getScorePlayer1(), 0, "Player 1 should have scored 1 goal");
        assertEquals(0, game.getScoreboard().getScorePlayer2(), 0, "Player 2 should have 0 goals");
        assertTrue(game.isGoalFreeze(), "Game should be in goal freeze celebration");
    }

    private static void testGoalFreezeAndReset() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();
        Ball ball = game.getBall();
        int leftGoalLine = game.getField().getLeftGoalLine();
        int goalTop = game.getField().getGoalTop();

        ball.setPosition(leftGoalLine - 2, goalTop + 40);
        ball.setVelocity(-10, 0);

        for (int i = 0; i < 5; i++) {
            game.update();
        }
        assertEquals(1, game.getScoreboard().getScorePlayer2(), 0, "Score should be 1");
        assertTrue(game.isGoalFreeze(), "Should enter goal freeze");

        for (int i = 0; i < 85; i++) {
            game.update();
        }

        assertEquals(1, game.getScoreboard().getScorePlayer2(), 0, "Score must still be 1 (no double counting)");
        assertTrue(!game.isGoalFreeze(), "Goal freeze should have ended");

        assertEquals(450.0, ball.getPositionX(), 1.0, "Ball should be reset to center pitch");
    }

    private static void testClockAndMatchEnd() {
        HeadSoccer game = new HeadSoccer(900, 540);
        game.start();

        assertEquals(180, game.getRemainingTime(), 0, "Clock should start at 180 seconds (03:00)");

        game.tickSecond();
        assertEquals(179, game.getRemainingTime(), 0, "Clock should decrement by 1 second");

        game.setPaused(true);
        game.tickSecond();
        assertEquals(179, game.getRemainingTime(), 0, "Clock must NOT decrease while paused");

        game.setPaused(false);

        while (game.getRemainingTime() > 0) {
            game.tickSecond();
        }

        assertEquals(0, game.getRemainingTime(), 0, "Clock should reach 00:00");
        assertTrue(!game.isRunning(), "Game should finish when clock reaches zero");
    }
}
